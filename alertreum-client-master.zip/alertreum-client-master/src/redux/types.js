export const OPEN_CLOSE_NAV = 'OPEN_CLOSE_NAV';
export const SET_NOTIFY = 'SET_NOTIFY';
export const PROFILE = 'PROFILE';
export const CRYPTOLIST = 'CRYPTO';
export const UNSET_NOTIFY = 'UNSET_NOTIFY';
export const LOGIN = 'LOGIN';
export const LOGOUT = 'LOGOUT';