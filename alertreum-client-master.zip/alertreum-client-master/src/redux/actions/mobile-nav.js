import { OPEN_CLOSE_NAV } from '../types';

export const mobileNavAction = () => ({
    type: OPEN_CLOSE_NAV
})
