export const httpURL = 'http://localhost:8000';
export const webSocketURL = 'ws://localhost:8000';